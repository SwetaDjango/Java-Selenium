package TestNg;

import org.testng.annotations.Test;

public class xyz {
  @Test
  public void f() {
  }
}

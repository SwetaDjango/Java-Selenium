package TestNg;

import org.testng.annotations.Test;

public class sampleXmlTest {
  @Test
  public void f() {
  }
}

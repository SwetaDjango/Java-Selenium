package TestNg;

import org.junit.Assert;
import org.testng.annotations.Test;

public class TestNgEnabledAttribute {
	@Test (priority = 3)
	public void abcd(){
	Assert.assertEquals("Gmail", "Gmail");
	}
	@Test (priority = 1, enabled = false)
	public void xyz(){
	Assert.assertEquals("Google", "Google");
	}
	@Test (priority = 2)
	public void pqr(){
	Assert.assertEquals("Yahoo", "Yahoo");
}
}

package TestNg;

//import org.junit.AfterClass;
import org.junit.Assert;
//import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class BeforeafterClass {
	public  WebDriver driver;


	@BeforeClass
	public void launchBrowser(){
		System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");
		//WebDriver driver = new FirefoxDriver();   //duplicate declaration
		driver = new FirefoxDriver(); 
		//driver.get("https://www.gmail.com");
	}

	@Test 
	public void verifyPageTitle1(){
		driver.get("https://www.gmail.com");
		Assert.assertEquals("Gmaiyyl", driver.getTitle());
	}

	@Test
	public void verifyPageTitle2(){
	driver.get("https://in.yahoo.com/");
	Assert.assertEquals("Yahoo", driver.getTitle());
	}
	
	@AfterClass
	public void closeBrowser(){
	driver.quit();
 }
}

package TestNg;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class TestNgPriorityAttribute {
	/*
	 * @Test(priority=6) public void c_method(){
	 * System.out.println("I'm in method C"); }
	 * 
	 * @Test(priority=9) public void b_method(){
	 * System.out.println("I'm in method B"); }
	 * 
	 * @Test(priority=1) public void a_method(){
	 * System.out.println("I'm in method A"); }
	 * 
	 * @Test(priority=0) public void e_method(){
	 * System.out.println("I'm in method E"); }
	 * 
	 * @Test(priority=3) public void d_method(){
	 * System.out.println("I'm in method D"); }
	 */
	public WebDriver driver;
	
	@Test (priority=1)
	public void launchBrowser(){
	System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");
	driver = new FirefoxDriver();    
	}

	@Test (priority=3)
	public void verifyPageTitle1(){
	driver.get("https://www.gmail.com");
	Assert.assertEquals("Gmail", driver.getTitle());
	}

	@Test(priority=2)
	public void verifyPageTitle2(){
	driver.get("https://in.yahoo.com/");
	Assert.assertEquals("Yahoo", driver.getTitle());
	}
	@Test (priority=4)
	public void closeBrowser(){
	driver.quit();
	}
}

  
/*
 * @Test() public void c_method(){ System.out.println("I'm in method C"); }
 * 
 * @Test() public void b_method(){ System.out.println("I'm in method B"); }
 * 
 * @Test() public void a_method(){ System.out.println("I'm in method A"); }
 * 
 * @Test() public void e_method(){ System.out.println("I'm in method E"); }
 * 
 * @Test() public void d_method(){ System.out.println("I'm in method D"); }
 */
}
}

//}

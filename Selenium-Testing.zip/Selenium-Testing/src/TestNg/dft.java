package TestNg;

import org.testng.Assert;
import org.testng.annotations.Test;

public class dft {

	/*@Test
	public void A(){
	Assert.assertEquals("Gmail", "Gmail");
	}
	
	@Test
	public void C(){
	Assert.assertEquals("Gmail", "Google");
	}
	@Test
	public void B(){
	Assert.assertEquals("Yahoo", "Yahoo");
	}*/
	
	@Test(priority = 2)
	public void abc(){
	Assert.assertEquals("Gmail", "Gmail");
	}
	
	@Test(priority = 0)
	public void xyz(){
	Assert.assertEquals("Gmail", "Google");
	}
	
	@Test(priority = 1)
	public void jik(){
	Assert.assertEquals("Yahoo", "Yahoo");
	}

}

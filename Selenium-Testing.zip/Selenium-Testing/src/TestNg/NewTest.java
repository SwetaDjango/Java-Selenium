package TestNg;


//import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class NewTest {
	
	
  @Test
  public void verifyTitle(){
	  System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");
	  WebDriver driver = new FirefoxDriver();    
	  driver.get("https://www.gmail.com");
	  String pageTitle = driver.getTitle();
	//  Assert.assertArrayEquals(expecteds, actuals);
	  Assert.assertEquals(pageTitle, "Gmail");
	  

	  

	

  }
}

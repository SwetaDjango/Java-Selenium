package TestNg;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Sample2 {
	@Test
	public void testA() {
		Assert.assertEquals("Gmail", "Gmail");
	}

	@Test
	public void testC() {
		Assert.assertEquals("Gmail", "Google");
	}

	@Test
	public void testB() {
		Assert.assertEquals("Yahoo", "Yahoo");

	}
}

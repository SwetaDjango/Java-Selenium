package TestNg;

import org.testng.annotations.Test;

public class TestNgDependson {
 
@Test
  public void login(){
	  System.out.println("Login Successful");
	  }
  
	  @Test (dependsOnMethods = {"login"})
	  public void search(){
	  System.out.println("Search Successful");
	  }
	  
	  @Test (dependsOnMethods = {"search"})
	  public void advancedSearch(){
	  System.out.println("Advanced Search Successful");
	  }
	  
	  @Test (dependsOnMethods = {"advancedSearch"})
	  public void logout(){
	  System.out.println("Logout Successful");

/*
		@Test
			public void login(){
		  System.out.println("Login Successful");
		  }
		 
	 		
	 	@Test (dependsOnMethods = {"login"})
		  public void search(){
		  Assert.assertEquals("XYZ", "XYSZ");
		  }
	 	
		  @Test (dependsOnMethods = {"search"}) //, alwaysRun=true
		  public void advancedSearch(){
			  Assert.assertEquals("XYZ", "XYZ");
		  }
		  
		  @Test (dependsOnMethods = {"advancedSearch"})
		  public void logout(){
		  System.out.println("Logout Successful");*/

	//alwaysRun attribute
/*
		@Test
	      public void login(){
		  System.out.println("Login Successful");
		  }
	
		  @Test (dependsOnMethods = {"login"})
		  public void search(){
		  Assert.assertEquals("XYZ", "XYZ");
		  }
		  
		  @Test (dependsOnMethods = {"search"})
		  public void advancedSearch(){
			  Assert.assertEquals("XYZ", "XYAZ");
		  }
		  
		  @Test (dependsOnMethods = {"advancedSearch"}, alwaysRun=true)
		  public void logout(){
		  System.out.println("Logout Successful");
*/
	  }
}


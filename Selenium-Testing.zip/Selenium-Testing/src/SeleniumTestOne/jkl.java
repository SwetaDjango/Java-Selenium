package SeleniumTestOne;

public interface jkl {
	
	

}

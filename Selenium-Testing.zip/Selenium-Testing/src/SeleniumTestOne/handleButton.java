package SeleniumTestOne;

import java.awt.Button;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class handleButton {

	public static void main(String[] args) {
		
		
		//System.setProperty("webdriver.gecko.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\geckodriver-v0.19.1-win64\\geckodriver.exe");
		//System.setProperty("webdriver.chrome.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\chromedriver_win32\\chromedriver.exe");
		System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");
		
		
		//WebDriver driver= new ChromeDriver();
		WebDriver driver= new FirefoxDriver();
		
		driver.get("https://login.yahoo.com/");
		
		WebElement button=driver.findElement(By.id("login-signin"));
		
		
		System.out.println(button.isDisplayed());
		System.out.println(button.isEnabled());
		
		//driver.findElement(By.id("login-username")).sendKeys("khuveio_samson");
		
		
		
		button.click();
		
		//driver.findElement(By.id("login-signin")).click();
		//System.out.println(driver.findElement(By.id("login-signin")).isEnabled());
		
		System.out.println(button.getAttribute("type"));//submit
		System.out.println(button.getAttribute("name"));//signin
		System.out.println(button.getAttribute("value"));//Next
		
		
		

	}

}

package SeleniumTestOne;

public class JavaInheriClassX {
	
	protected int a =10; //protected
	protected  int b =20;

	protected void add(){
	System.out.println(a+b);
	}


	public static void main(String[] args) {

		JavaInheriClassX objX = new JavaInheriClassX();
		System.out.println(objX.a);
		
		objX.add();


	}

}

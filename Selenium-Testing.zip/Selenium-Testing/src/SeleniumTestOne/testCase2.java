package SeleniumTestOne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class testCase2 {

	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		driver.get("https://www.google.com");
		boolean existence =driver.findElement(By.linkText("Gmail")).isDisplayed();
		if (existence==true) {
			System.out.println("Gmail link exists");
		}
		
		else {
			System.out.println("Gmail link doesnt exists");
		}

	}

}

package SeleniumTestOne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;

public class radioButton {

	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\geckodriver.exe");
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("http://www.gcrit.com/build3/create_account.php?osCsid=47gtsrhe41613u5r3eqhgdbas7");
		//WebElement maleradioButton = driver.findElement(By.xpath("html/body/div[1]/div[3]/form/div/div[2]/table/tbody/tr[1]/td[2]/input[1]"));
		
		WebElement maleradioButton = driver.findElement(By.name("gender"));
		
		
		System.out.println(maleradioButton.isDisplayed());//True
		System.out.println(maleradioButton.isSelected());//false
		System.out.println(maleradioButton.isEnabled());//True
		
		maleradioButton.click();
		System.out.println(maleradioButton.isSelected());//true
		
	}

}

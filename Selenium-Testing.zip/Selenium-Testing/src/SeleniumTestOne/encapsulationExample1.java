package SeleniumTestOne;

public class encapsulationExample1 {

	private String name = "Test Automation";

	public String getName(){
	return name; //private
	}
	public void setName(String newName){
	name=newName;    
	}

	public static void main (String [] args){
		encapsulationExample1 obj = new encapsulationExample1();
	
	obj.setName(("ert"));//name= ert
	System.out.println(obj.getName());

	}

}

package SeleniumTestOne;

public class SampleCalc {
	
	public int add(int a, int b) {
		System.out.println(a+b);
		return (a+b);
		
		
		
	}
	
	public int mul(int a, int b, int c) {
		return (a*b*c);
		
	}
	
	public void display(String s) {
		System.out.println("My name is "+ s);
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SampleCalc obj = new SampleCalc(); // Create a object of the class
		
		int x =obj.add(2, 3);
		
		System.out.println(x);
		
		int y=obj.mul(3, 3, 10);
		
		System.out.println(y);
		
		obj.display("David");
		

		
		

	}

}

package SeleniumTestOne;

public class SanityTest extends JavaInheriClassA{

	public static void main(String[] args) {
		System.out.println("My first Program");
		
		//JavaInheriClassA obj1 = new JavaInheriClassA();
		SanityTest obj2= new SanityTest();
		
		obj2.add();
		

	}

}

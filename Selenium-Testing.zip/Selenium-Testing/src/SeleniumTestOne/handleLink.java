package SeleniumTestOne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class handleLink {

	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");
		WebDriver driver= new FirefoxDriver();
		
/*		//General Image (No functionality)
		
		driver.get("https://login.yahoo.com/");
		String abc=driver.getTitle();
		if (abc=="Yahoo")
		{
			System.out.println("title matched with the expected");
		}*/
			
		driver.get("https://login.yahoo.com/");
		WebElement link= driver.findElement(By.linkText("Help"));
	
		
	System.out.println(link.isDisplayed());//True
	System.out.println(link.isEnabled());//True
	System.out.println(link.getText());//Help
	link.click();//Click Operation
	
	
	}

}

package SeleniumTestOne;

public class encapsulationExample2 extends encapsulationExample1 {

	public static void main(String[] args) {
		encapsulationExample2 obj2 = new encapsulationExample2();
		//obj2.setName("Selenium");//name=Selenium
		System.out.println(obj2.getName());//getter method


	}

}

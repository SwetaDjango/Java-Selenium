package SeleniumTestOne;

public class JavaStrings {

	public static void main(String[] args) {
		
		
		  String str1 = "Selenium";
		  String str2 =" Testing";
		  System.out.println(str1+str2);//SeleniumTesting
		  
		  System.out.println("Selenium" + (1 + 1));//Selenium2
		  //"selenium" + 2 -->String+ Int =String
		  
		  
		  System.out.println("Selenium" + 1 + 1);//Selenium11
		  System.out.println(1 + 1+"Selenium");//2Selenium 
		  System.out.println("1" + 1 +"Selenium");//11Selenium
		  System.out.println("Selenium" + " ");
		  System.out.println(" " + "Selenium");
		 
		 
	
		//String Comparision
	
		
/*		  String str1 = "selenium"; //s+e+l
		  String str2 = "SELENIUM";
		  String str3 = "SELENIUM";
		  String str4 = "zselenium";
		 
		  //String Comparison using == Operator 
		  System.out.println(str1 ==str2);//false 
		  System.out.println(str2 == str3);//true
		  
		  //String Comparison using equals() method
		  
		  str1.equals(str2); //true or false
		  
		  
		  System.out.println(str1.equals(str2));//false
		  System.out.println(str2.equals(str3));//true
		  
		  //String Comparison using compareTo() method
			
			  str2.compareTo(str1); 
			  System.out.println(str1.compareTo(str2));//Greater than0 
			  System.out.println(str2.compareTo(str3));//0
			  System.out.println(str1.compareTo(str4));//Less than 0 str1-str4
			 		 
		
		


	}*/

}}

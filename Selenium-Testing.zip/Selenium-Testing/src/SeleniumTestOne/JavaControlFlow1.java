package SeleniumTestOne;

public class JavaControlFlow1 {

	public static void main(String[] args) {
		
  int a, b, c,d;
  a=9000000;
  b=5000;
  c=90; 
  d=900;

	/*
	 * if (a > b){ // true System.out.println("A is a Big Number"); }
	 * 
	 * 
	 * else {
	 * 
	 * System.out.println("B is a Big Number");
	 * 
	 * 
	 * }
	 */
		 

		//Execute a block of statements when a compound Condition is True
		

		/*
		 * if ((a > b) && (a > c)) { System.out.println("A is a Big Number"); }
		 */
		   
		
	//Decide among several alternates (else if structure)
		  

// 1 to 100
	    if ((a >= 1) && (a <= 100)){
	        System.out.println("A is a Small Number");
	    }
	    
	   // between 101 and 1000 
	    
	    else if ((a > 100) && (a <= 1000)){ //101 to 1000
	    System.out.println("A is a Medium Number");
	    }
	    
	    //between 1001 and 10000 
	    
	    else if ((a > 1000) && (a <= 10000)){
	        System.out.println("A is a Big Number");
	        
	        //>10000
	        }
	    else if (a > 10000) {
	        System.out.println("A is High Number");
	        }
	    else
	    {
	        System.out.println("A is either Zero or Negative Number");
	    }
	    
	



		//Else part for all conditions   a=210; b=5000; c=90; d=900;
	
	    if (a> b){
		    	if (a>c){
		    		if (a>d){
		    					System.out.println("A is a Big Number");
		    				}
		    		else // for 3rd condition (A<D)
		    			{
		    				System.out.println("D is Big No");
		    			}
		    		}
		    	else  //for 2nd condition (A<C)
		    		{
		    			System.out.println("C is BIG No ");
		    		}
		    	}
		 else  // for 1st Cond (A<B)
		    	{
		    	System.out.println("A is Not a Big Number");
		    	}
		    }
}


	
	




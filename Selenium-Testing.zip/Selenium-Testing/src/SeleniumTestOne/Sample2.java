package SeleniumTestOne;

public class Sample2 {
	
	//Multiply method is external method to Sample 2 class
	
	//Create internal add method
	public int add(int a, int b, int c){
	int result = a + b + c;
	return result;
	}
	  
	public static void main (String [] args){

	//Create Object
	Sample2 obj1 = new Sample2(); // calling internal method

	//Calling Internal method
	int x = obj1.add(10, 25, 35);
	System.out.println(x);

	
	
	//System.out.println(Sample1.multiply(10,25, 35)); // without invoking object.
	
	//Create Object  for accessing external method.  
	Sample1    obj2 = new Sample1();

	//Calling External Method by invoking object.
	int y = obj2.multiply(10, 25, 35);
	System.out.println(y);
	}

}

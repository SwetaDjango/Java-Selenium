package SeleniumTestOne;

import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class EditBox {

	public static void main(String[] args) throws InterruptedException {
		
		
		//System.setProperty("webdriver.gecko.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\geckodriver.exe");
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\chromedriver_win32\\chromedriver.exe");
		
		
		
		WebDriver driver= new ChromeDriver();
		driver.get("http://www.gcrit.com/build3/admin/login.php");
		Thread.sleep(2000);
		
		//System.out.println("iam here..");
		//driver.findElement(By.xpath(".//*[@id='contentText']/table/tbody/tr[2]/td/form/table/tbody/tr[1]/td/input")).sendKeys("admin");
		
		WebElement username=driver.findElement(By.name("username"));
	    Point text1=username.getLocation();
		System.out.println(text1);
		
		username.sendKeys("adminert"); //Entering values in edit box
		//System.out.println(username.getAttribute("type")); //Return the type of object
		String text=username.getAttribute("value");
		System.out.println(text);//Return the value in the edit box
		System.out.println(username.isDisplayed());//Return the Displayed status
		System.out.println(username.isEnabled());//Return the enabled status
		//Thread.sleep(5000);
		username.clear(); //Clear the value.
		
		
		
		

	}

}

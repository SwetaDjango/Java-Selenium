package SeleniumTestOne;

public  class JavaModifiers //default
 {
	
	//a Variable is a Class/Static variable
	
	//Program to show the accessmodifiers in Java
	
	 static int a =100;
	//int b= 300;
	char e='H'; //Instance variable 
	

	
	

	//Methods SalaryC(method)
	public static int salary(){
	    int mysalary =10000+2000+1500; //mysalary variable is a Local variable.- declared in methods or blocks.
	    mysalary=mysalary + a;
	    return mysalary;
	}
	
	//public abstract  void grade(); //signature


	public static void main(String[] args) {
		//Instance variable b (Instance variables are declared in a class but outside of a method or any block)
		int b =200;
		//int a=400;
		//System.out.println(a);//100
		//System.out.println(JavaModifiers.a);
		
		System.out.println(b); //200    
		        
		JavaModifiers object= new JavaModifiers();
		
		//System.out.println(object.a);
		System.out.println(a);
		
		int result =salary();
		
		//int result =JavaModifiers.salary();
		
		int result2= JavaModifiers.salary();
		
		System.out.println(result);
		
		//int var=JavaModifiers.a;
		
		//System.out.println(var);
		
		
		
		
		//System.out.println(obj.salary());
		// i is a Local Variable    
		for (int i=1; i<=5; i++){  // 1 to 5
		    System.out.println(i);
		    System.out.println(a);
		    System.out.println(b);



		}

	}
}

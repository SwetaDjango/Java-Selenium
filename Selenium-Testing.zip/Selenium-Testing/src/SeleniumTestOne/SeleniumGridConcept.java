package SeleniumTestOne;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
 
import java.net.MalformedURLException;
import java.net.URL;


public class SeleniumGridConcept {

	public static WebDriver driver;
	
	public static String  URL, Node;
	 
	public static void main(String[]  args) throws MalformedURLException, InterruptedException{
 
 		 URL = "http://www.DemoQA.com";
 		 Node = "http://192.168.1.4:5555/wd/hub";
 		//System.setProperty("webdriver.gecko.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\geckodriver.exe");
 		//System.setProperty("webdriver.chrome.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\chromedriver_win32\\chromedriver.exe");
 		DesiredCapabilities cap = DesiredCapabilities.chrome();
 		//cap.setBrowserName("chrome");
 		//cap.setPlatform(Platform.XP);
 		
 
 		driver = new RemoteWebDriver(new URL(Node), cap);
 
 		driver.navigate().to(URL);
 		Thread.sleep(5000);
 		driver.quit();
 	}		


}

package SeleniumTestOne;

public class SampleJavaProgram {

	
		//Create a Method(User defined)
		public int multiply( int a, int b, int c){
		int result = a * b * c;
		return result;
		}

		public static void main (String [] args){
		// This is a sample Program

		int a = 10, b=20, c=30; //Variables Declaration    

		final int money =100;//Constant Declaration

		System.out.println("Addition of a, b is " + (a + b));//Addition of a, b is 30
		System.out.println(money);//100
		System.out.println(c);//30

		//Condition Block
		if (a > b){
		System.out.println("A is a Big Number");
		}
		else
		{
		System.out.println("B is a Big Nuber");
		}

		//Loop block

		for (int d=1; d <=10; d++){ //d=1 -->1<=10 (T) :1 will be printed on console : 1+1=2=d
			//2 : 2<=10 : 2 will be printed on console : d=2+1=3
			//3
			//4
			//10 : 10<=10; 10 will be printed : d=10+1=11
			//11  :11<=10 (FALSE) come out of the loop
		    System.out.println(d);
		}
		//Create Object and access Methods
		SampleJavaProgram obj1 = new SampleJavaProgram();
		
		int output =obj1.multiply(10, 20, 30);
		
		System.out.println(output);
		
		
}
}



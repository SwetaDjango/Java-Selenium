package SeleniumTestOne;

public class RunTimePolymorphism1 extends RunTimePolymorphism { 
	
	public void myMethod(){
		System.out.println("UFT for Test Automation");
		}

		public static void main(String[] args) {

			RunTimePolymorphism1 obj1=new RunTimePolymorphism1();
			obj1.myMethod();
			
			RunTimePolymorphism obj2=new RunTimePolymorphism();
			obj2.myMethod();

	}

}

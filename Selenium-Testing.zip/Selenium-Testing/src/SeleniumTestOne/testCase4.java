package SeleniumTestOne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;

public class testCase4 {

	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");
		
		//Positive Test Case
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\chromedriver_win32\\chromedriver.exe");
/*		WebDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://www.gcrit.com/build3/admin/");
		driver.findElement(By.name("username")).sendKeys("admin");
		driver.findElement(By.name("password")).sendKeys("admin@123");
		driver.findElement(By.id("tdb1")).click();
		String url= driver.getCurrentUrl();
		if (url.equals("http://www.gcrit.com/build3/admin/index.php"))
		{
			System.out.println("Login Successful. Test case passed.");
		}
		else {
			System.out.println("Login Failed. Test case failed.");
		}
			*/
		
		//Negative test case
	WebDriver driver= new ChromeDriver();
	driver.get("http://www.gcrit.com/build3/admin/");
	driver.findElement(By.name("username")).sendKeys("adminaqwe");
	driver.findElement(By.name("password")).sendKeys("admin@123");
	driver.findElement(By.id("tdb1")).click();
	String error= driver.findElement(By.className("messageStackError")).getText();
	System.out.println(error);
	
	if (error.contains("Error: Invalid administrator login attempt."))
	{
		System.out.println("Handling error message successful. Test case passed.");
	}
	else {
		System.out.println("NOt able to capture expected error message. Test case failed.");
	}
	
	driver.close();
	

	}

}

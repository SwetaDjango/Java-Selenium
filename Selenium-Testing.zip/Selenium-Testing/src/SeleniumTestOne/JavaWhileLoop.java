package SeleniumTestOne;

public class JavaWhileLoop {

	public static void main(String[] args) {
		//Print 1 to 10 Numbers

		/*
		 * int i = 1; while (i <= 10) { System.out.println(i); i++; }
		 */

		
	//Print 10 to 1 Numbers
	
	/*
	 * int i = 10; while (i >= 1) { System.out.println(i); i--; }
	 */
	 
		
		//Print 1 to 10 Numbers except 7

		int i = 1; //initialization
		while (i <= 10) { // condition if true go inside body of loop
			if (i != 7) {
				System.out.println(i);
			}
			i++; //incrementing
		}


	}

}

package SeleniumTestOne;


import java.io.File;
import java.io.IOException;


public class JavaFileHandling {

	public static void main(String[] args) throws IOException{
		
	//Create a Folder

		File fileObject = new File("C:\\Sweta\\XYZ");

		fileObject.mkdir();
	
	
//Check the existence of  Folder.
		
/*File fileObject = new File("C:\\Users\\Sweta\\Desktop\\Manual Testing\\Java\\123fbd");
		boolean a = fileObject.exists();
		        
		if (a == true){
		System.out.println("Folder Exists");
		}
		else {
		System.out.println("Folder Not Exists");
		}
*/
		
		//Delete a Folder
	
/*        File fileObject = new File("C:\\Users\\Sweta\\Desktop\\Manual Testing\\Java\\xyz");
		fileObject.delete();
*/
		
		//Create a Text File
	
/*	File fileObject = new File("C:\\Users\\Sweta\\Desktop\\Manual Testing\\Java\\TestExcel.xls");
		fileObject.createNewFile();
*/		

		
		//Delete a Text File
	
//File fileObject = new File("C:\\Users\\Sweta\\Desktop\\Manual Testing\\Java\\TestExcel.xls");
		//fileObject.delete();



	}

}

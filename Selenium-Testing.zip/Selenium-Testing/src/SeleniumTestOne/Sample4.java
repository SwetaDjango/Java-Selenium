package SeleniumTestOne;


//Calling external method without invoking object.
public class Sample4 {

	public static void main(String[] args) {
		Sample3.studentRank(700);
		
/*Sample3 obj1= new Sample3();
obj1.studentRank(800);*/

	}

}

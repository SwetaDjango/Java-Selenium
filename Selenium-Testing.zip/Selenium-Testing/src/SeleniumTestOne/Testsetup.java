package SeleniumTestOne;

public class Testsetup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println("Hello world");
		int a=10;
		
		int b = 20;
		System.out.println("Addition of a and b is :" + (a+b));
		char c ='A';
		double d= 123.3456;
		boolean e= true;
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
				
		

	}

}

package SeleniumTestOne;

public class CallingMethodbyObject1 {
	
	//Create Method
	public void studentRank(int marks){
	if (marks >= 600){
	System.out.println("Rank A");
	}
	else if (marks >= 500){
	System.out.println("Rank B");
	}
	else
	System.out.println("Rank C");
	}


	public static void main(String[] args) {
		
		//Call method by invoking object
		CallingMethodbyObject1 obj = new CallingMethodbyObject1();
		obj.studentRank(200);

		int x=callExternalMethodbyObject.multiply(10, 20, 30);
		System.out.println(x);


	}

}

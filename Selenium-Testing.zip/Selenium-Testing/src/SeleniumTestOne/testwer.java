package SeleniumTestOne;

public class testwer {
	
	//Multiply method
public int multiply(int a, int b, int c){
		int result = a * b * c;
		return result;
		}


	public static void main(String[] args) {
		

		
		System.out.println("My first Java prgm");
		
		testwer obj = new testwer();
		int x=obj.multiply(10, 20, 30);
		System.out.println(x);


	}

}

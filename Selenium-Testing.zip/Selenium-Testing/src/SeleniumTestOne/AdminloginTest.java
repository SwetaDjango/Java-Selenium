package SeleniumTestOne;


import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class AdminloginTest {

	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");	
	    WebDriver driver = new FirefoxDriver();
	    System.out.println("Opening the google site");
        driver.get("https://accounts.google.com/ServiceLogin?service=mail&passive=true&rm=false&continue=https://mail.google.com/mail/&ss=1&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1#identifier");
        //driver.findElement(By.id("Email")).sendKeys("testsele7");
        //driver.findElement(By.id("Next")).click();
        //driver.findElement(By.id("Passwd")).sendKeys("Admin111");
        
        /*       
        driver.findElement(By.xpath(".//div/input[contains(@name,'Email') or contains(@autocomplete,'username')]")).sendKeys("testsele7");
        driver.findElement(By.xpath(".//div/input[contains(@value,'Next')] or .//content/span[contains(text(),'Next')]")).click();
        driver.findElement(By.xpath(".//div/input[contains(@name,'Passwd') or contains(@type,'password')]")).sendKeys("Admin111");
        driver.findElement(By.xpath(".//div//[contains(@name,'signIn') or contains(text(),'Next')]")).click();
        
        driver.findElement(By.xpath(".//div/input[contains(@name,'Email') or .//div/input[contains(@autocomplete,'username')]")).sendKeys("testsele7");
        driver.findElement(By.xpath(".//div/input[contains(@value,'Next')] or .//content/span[contains(text(),'Next')]")).click();
        driver.findElement(By.xpath(".//div/input[contains(@name,'Passwd')] or .//div/input[contains(@type,'password')]")).sendKeys("Admin111");
        driver.findElement(By.xpath(".//div/input[contains(@name,'signIn')] or .//content/span[contains(text(),'Next')]")).click();
        System.out.println("I'm inside the mail box.");
       */ 
        		
        driver.findElement(By.xpath(".//div/input[contains(@name,'Email') or contains(@autocomplete,'username')]")).sendKeys("testsele7");
               
        Boolean isPresent = driver.findElements(By.xpath(".//div/input[contains(@value,'Next')]")).size() > 0;
        if (isPresent==true) {
        	WebElement asd=driver.findElement(By.xpath(".//div/input[contains(@value,'Next')]"));
        	asd.click();
        }else {
        	WebElement asdw= driver.findElement(By.xpath(".//content/span[contains(text(),'Next')]"));
        	asdw.click();
        }
        
        driver.findElement(By.xpath(".//div/input[contains(@name,'Passwd') or contains(@type,'password')]")).sendKeys("Admin111");
        
/*
        WebElement asdf=driver.findElement(By.xpath(".//div/input[contains(@name,'signIn')]"));
        if (asdf.isEnabled()) {
        	asdf.click();
        }else {
        	WebElement asdwq= driver.findElement(By.xpath(".//content/span[contains(text(),'Next')]"));
        	asdwq.click();
        }*/
        
        
        
	}	
	

}

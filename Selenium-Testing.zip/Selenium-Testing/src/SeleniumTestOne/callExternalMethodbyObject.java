package SeleniumTestOne;

public class callExternalMethodbyObject {
	
	//Create Method
	public static int multiply(int a, int b, int c){
	int result = a * b * c;
	return result;
	}
	
	



}

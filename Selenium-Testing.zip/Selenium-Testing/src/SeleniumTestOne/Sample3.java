package SeleniumTestOne;

public class Sample3 {
	
	//Create Internal void Method
	public static void studentRank(int marks){
	if (marks >= 600){
	System.out.println("Rank A");
	}
	else if (marks >= 500){
	System.out.println("Rank B");
	}
	else{
	System.out.println("Rank C");
	}
	}

	public static void main (String [] args){
	//Call method without object
	//Sample3.studentRank(550);//studentRank(750);
	
	Sample3 obj= new Sample3();
	obj.studentRank(700);
	}

}

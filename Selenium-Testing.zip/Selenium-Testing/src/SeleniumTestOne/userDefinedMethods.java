package SeleniumTestOne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class userDefinedMethods {
	
	
	
	public static WebDriver driver;
	//Launch Browser
	public void launchBrowser(){
    driver= new FirefoxDriver();   
	}
	//Admin Login without Parameters
	
	public void adminLogin(){
	driver.get("http://www.gcrit.com/build3/admin/");
	driver.findElement(By.name("username")).sendKeys("admin");
	driver.findElement(By.name("password")).sendKeys("admin@123");
	driver.findElement(By.id("tdb1")).click();
	}
	
	//Admin Login With Parameters
	
	public void adminLogin(String username, String password){
	driver.get("http://www.gcrit.com/build3/admin/");
	driver.findElement(By.name("username")).sendKeys(username);
	driver.findElement(By.name("password")).sendKeys(password);
	driver.findElement(By.id("tdb1")).click();
	}
	//Close Browser
	public void closeBrowser(){
	if (! driver.toString().contains("null")){
	driver.close();
	}

	}

public static void main(String[] args)  {
	
	System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");
	//System.setProperty("webdriver.gecko.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\geckodriver-v0.19.1-win64\\geckodriver.exe");
	
	//C:\Users\Sweta\Desktop\Manual Testing\Download\New folder\geckodriver-v0.19.1-win64
	//System.setProperty("webdriver.chrome.driver", "C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\chromedriver_win32\\chromedriver.exe");

	
	userDefinedMethods obj= new userDefinedMethods();
	obj.launchBrowser();
	obj.adminLogin();
	//obj.closeBrowser();
	//Thread.sleep(5000);
	obj.launchBrowser();
	obj.adminLogin("admin", "admin@123");
	//obj.closeBrowser();
		 		
	

	}

}

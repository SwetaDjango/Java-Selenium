package SeleniumTestOne;

public class JavaForLoop {

	public static void main(String[] args) {
	//Print 1 to 10 Numbers
		
		//range is from 1 to 10
		/*
		 * for(int i=1; i<=10; i++){ System.out.println(i); }
		 */

		

		
	//Print 10 to 1 Numbers
/*
	for(int i=10; i>=1; i--){
		System.out.println(i);
		}
*/
		
//Print 1 to 10 Numbers except 7

/*		for(int i=1; i<=10; i++){
		if (i != 7){
		System.out.println(i);
		}*/
	
	
		
		//Print 1 to 10 Numbers except 4th number and 7th Number

		for(int i=1; i<=100; i++){
		if ((i != 45) && (i != 78)){
		System.out.println(i);
		}
		




	}
}}

package SeleniumTestOne;


public class JavaOperators {

	
	
	
	public static void main(String[] args) {
		
		
		//post and pre increment and decrement
		/*
		 * int p= 10; System.out.println(p); int q= ++p; System.out.println(q);
		 * System.out.println(p); p++; System.out.println(p);
		 */
		
		
		
		//Arithmetic Operators
		
		
		  int a =10, b=5; //Declaration of variables int a,b; a=10; b=5 //
		  //String c="Selenium"; //String d= "Testing";
		  
		  System.out.println("Addition of a, b is: "+ (a+b));//Addition of a, b is: 15
		  System.out.println("Subtraction of a, b is: "+ (a-b));
		  System.out.println("Multiplication of a, b is: "+ (a*b));
		  System.out.println("Division of a, b is: "+ (a/b)); //2
		  System.out.println("Modules of a, b is: "+ (a%b));
		  
		  b=10; a = ++b; // a= b+1 =11 
		  System.out.println(a);//11
		  
		  b=10; a = b--; 
		  System.out.println(a);//10 
		  System.out.println(b);//9
		  
		  b=10; a = --b; //a=10
		  System.out.println(a);//10-->9 
		  System.out.println(b);//9
		 



		
		//##RELATIONAL Operators 
		/*
		 * int a =20, b=10; System.out.println((a>b));//false
		 * System.out.println((a>=b));//false System.out.println((a==b));//false
		 * 
		 * System.out.println((a<b));//true System.out.println((a<=b));//true
		 * System.out.println((a!=b));//true System.out.println(a==b);
		 */
		  
		 

		
		//LOGICAL Operators
		
		
		/*
		 * boolean a =true, b=false; System.out.println(!(a && b));//true !(FALSE)
		 * System.out.println((a || b));//false System.out.println((a || b));//true
		 */		 		 

		//ASSIGNEMENT OPERATORS
		
		
		/*
		 * int a =30;
		 * 
		 * System.out.println(a);//10 a+=10; // a=a+10 System.out.println(a);//20
		 * 
		 * a-=10; //a=a-10 =30-10 =20 System.out.println(a);//10
		 * 
		 * a*=10;// a=a*10 System.out.println(a);//200
		 */		 
	}

}

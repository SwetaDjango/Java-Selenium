package SeleniumTestOne;

public class WebDriverwait {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

package SeleniumTestOne;

public class InterfaceImplementation implements SampleInterface {
	
	
	public void engine() {
			System.out.println("Bikes have Engine");
			}

	
	public void wheels() {
		System.out.println("Bikes have Wheels");
		
	}

	
	public void seat() {
		System.out.println("Bikes have Seat");
		
	}

	
	public void handle() {
		System.out.println("Bikes have handle");
		
	}

	public static void main(String[] args) {
		InterfaceImplementation obj= new InterfaceImplementation();
		obj.engine();
		obj.handle();
		obj.wheels();
		obj.seat();
		


	}

	
}

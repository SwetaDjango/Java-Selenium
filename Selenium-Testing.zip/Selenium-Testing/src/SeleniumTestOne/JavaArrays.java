package SeleniumTestOne;

public class JavaArrays {

	public static void main(String[] args) {

//Declaring Array
	
		/*int a [];//declaring an array.creating a int array with name a
		a = new int[3];//size of array is 3
		        
		a[0]=10;
		a[1]=20;
		a[2]=30;
		
		int b []={10,20,30,40};//declaring and assigning values
		System.out.println(a[0]);//10
		System.out.println(a[1] + a[2]);//50
		
		System.out.println(b[0]);//10
		System.out.println(b[3]);//40


		int [] abc = new int [4];
		abc[0] =10;
		System.out.println(abc[0]);    //10    

		
		int [] xyz = {10, 20, 30, 40}; //10-0, 20-1,30-2
		System.out.println(xyz[2]);//30 */

		
		/*char [] def = {'A', 'B', 'Z'}; //Array of Characters
		int [] pqr = {10, 20, 30, 40}; //Array of Integers
		String [] y = {"UFT", "Selenium", "RFT"}; //Array of Strings
		boolean [] b ={true, false, false, true}; //Array of Boolean values
		        
		System.out.println(def[1]);//B
		System.out.println(pqr[3]);//40
		System.out.println(y[1]);//Selenium
		System.out.println(b[2]);//false*/

		
		//$$$Copying Values of one array from another
		
		int [] array1 = {1, 2, 3, 4, 5};
		int array2 [] = array1;
		System.out.println(array2[2]);//3
		
		System.out.println(array2.length);
		System.out.println(array1.length);//size of array1
		        
		for (int i =0; i < array2.length; i++){// 0 to i<5
		System.out.println(array2[i]);//array2[0],array2[1],array2[2]

	}
		
	}

}

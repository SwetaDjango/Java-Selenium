package SeleniumTestOne;

public interface xyxd {

}

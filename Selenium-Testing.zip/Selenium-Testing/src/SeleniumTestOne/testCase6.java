package SeleniumTestOne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class testCase6 {

	public static void main(String[] args)  {
		System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");
		
		//System.setProperty("webdriver.gecko.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\geckodriver-v0.19.1-win64\\geckodriver.exe");
		
		
		WebDriver firefoxDriver = new FirefoxDriver();
		firefoxDriver.get("http://demoqa.com/");
		String text = firefoxDriver.findElement(By.className("entry-title")).getText();
		System.out.println(text);

		System.setProperty("webdriver.chrome.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\chromedriver_win32\\chromedriver.exe");
		WebDriver chromeDriver = new ChromeDriver();
		chromeDriver.get("http://www.gcrit.com/build3/create_account.php?osCsid=1vbg1oj32ole3qrcv4b6mr7m24");
		chromeDriver.findElement(By.name("firstname")).sendKeys(text);
		String text1=chromeDriver.findElement(By.xpath(".//*[@id='bodyContent']/h1")).getText();
		System.out.println(text1);
		
		//Thread.sleep(3000);

		System.setProperty("webdriver.ie.driver", "C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\IEDriverServer_x64_3.8.0\\IEDriverServer.exe");
		
		
		WebDriver IEDriver = new InternetExplorerDriver();
		IEDriver.get("http://newtours.demoaut.com/");
		IEDriver.findElement(By.name("userName")).sendKeys(text1);

		firefoxDriver.close();
		chromeDriver.close();
		IEDriver.close();

	}

}

package SeleniumTestOne;

public class JavaInheriClassB extends JavaInheriClassA  {

/*	int a =100;
	int b =200;
	public void add(){
	System.out.println(a+b);    
	}
*/

	public static void main(String[] args) {
		
		JavaInheriClassB objB= new JavaInheriClassB();
		
		objB.add();
		System.out.println(objB.a);//100
		

	}

}

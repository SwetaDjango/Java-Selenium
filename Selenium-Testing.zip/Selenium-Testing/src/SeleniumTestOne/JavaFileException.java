package SeleniumTestOne;

import java.util.Scanner;

public class JavaFileException {

	public static void main(String[] args) {
/*		Scanner scan = new Scanner(System.in);

		System.out.println("Read two Numbers");
		String s1= scan.nextLine(); //2
		String s2= scan.nextLine();//3
		
		System.out.println(s1+s2);

		int a = Integer.parseInt(s1);
		int b = Integer.parseInt(s2);
		System.out.println(a+b);

		scan.close();
*/	

	/*	int a =10;
		int b = 0;
		int result = a/b;
		System.out.println(result);
		System.out.println("Hello Java");
		System.out.println("Hello Selenium");
		
*/
		
		int a =10;
		int b = 0;
try
		{
		int result = a/b;
		System.out.println(result);
		}
		catch (ArithmeticException e){
		System.out.println("Divided by Zero Error");    
		}
		System.out.println("Hello Java");
		System.out.println("Hello Selenium");


	}


}


package SeleniumTestOne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class handleMousehover {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\chromedriver_win32\\chromedriver.exe");
		System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");
		WebDriver driver= new ChromeDriver();
		//WebDriver driver= new FirefoxDriver();
		driver.get("https://www.myntra.com/");
		driver.manage().window().maximize();
		//create Action builder instance by passing WebDriver instance as parameter
		
		Actions builder = new Actions(driver);
		WebElement menuElement = driver.findElement(By.xpath(".//*[@id='desktop-header-cnt']/div/nav/div/div[1]/div/a"));
		Thread.sleep(5000);
		builder.moveToElement(menuElement).build().perform();
		driver.findElement(By.xpath(".//*[@id='desktop-header-cnt']/div/nav/div/div[1]/div/div/div/ul[1]/li[6]/a")).click();

		
	}

}

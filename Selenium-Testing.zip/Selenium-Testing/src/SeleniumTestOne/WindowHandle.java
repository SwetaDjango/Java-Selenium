package SeleniumTestOne;

import java.util.ArrayList;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class WindowHandle {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.gecko.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\geckodriver.exe");
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
/*		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		String parent = driver.getWindowHandle();
		
		System.out.println(parent);
		
		driver.findElement(By.linkText("Gmail")).click();
	

		Set <String> Handles = driver.getWindowHandles();
		int BrowserCount = Handles.size();
		System.out.println(BrowserCount);

		for (String s1:Handles){
		if (! s1.equals(parent)){
		driver.switchTo().window(s1);
		System.out.println(driver.getCurrentUrl());
		}
		}
		driver.switchTo().window(parent);
		System.out.println(driver.getCurrentUrl());*/
		
		
		 driver.get("http://www.google.com");

		    WebElement element = driver.findElement(By.linkText("Gmail"));
		    Actions actionOpenLinkInNewTab = new Actions(driver);
		    actionOpenLinkInNewTab.moveToElement(element)
		            .keyDown(Keys.CONTROL) // MacOS: Keys.COMMAND
		            .keyDown(Keys.SHIFT).click(element)
		            .keyUp(Keys.CONTROL).keyUp(Keys.SHIFT).perform();


		    ArrayList<String> tabs = new ArrayList(driver.getWindowHandles());
		    driver.switchTo().window(tabs.get(1));
		    driver.get("http://www.yahoo.com");
		    //driver.close();

		    for (String s1:tabs){
				//if (! s1.equals(parent)){
				//driver.switchTo().window(s1);
				System.out.println(s1);
				
				}

	}

}

package SeleniumTestOne;

public class JavaDowhileLoop {

	public static void main(String[] args) {
		int i = 300;
		do
		{
		System.out.println(i);
		i++;//9
		} while (i<=7);
	
		
		//-----------------------------------
		
/*		  int i = 8; //initialization
		  do 
		  { System.out.println(i); //8
		  i++; } // 9
		  while (i<=10);// 9 <=10
		  //(dISPLAYED)--->9+1=10--->10<=10 (true)-->dIAPL10-->11 (cOND FALSE)
		 	}*/

}}

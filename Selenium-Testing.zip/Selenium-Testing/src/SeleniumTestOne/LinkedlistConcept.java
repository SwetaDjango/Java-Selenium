package SeleniumTestOne;

import java.util.LinkedList;

public class LinkedlistConcept {

	public static void main(String[] args) {

		LinkedList<String> ll= new LinkedList<String>();
		
		
		
		ll.add("QTP");
		ll.add("QTP");
		ll.add("Selenium");
		ll.add("RFT");
		
		System.out.println("Contents of linked list:" + ll);
		
		//addfirst
		
		ll.addFirst("Sweta");
		
		ll.addLast("Rawat");
		
		System.out.println("Contents of linked lisr:" + ll);
		
		//get and Set Value
		
		ll.set(0, "Manisha");
		
		System.out.println(ll.get(0));
		
		//remove first and last
		
		ll.removeFirst();
		
		ll.removeLast();
		
		System.out.println("Contents of linked lisr:" + ll);
		
		//print all emements of linkedlist
		
		for(int n=0;n<ll.size();n++)
		{
			System.out.println(ll.get(n));
		}
		
		
		
		

	}

}

package SeleniumTestOne;

public class CallingMethodbyObject {
	
	//User defined Method
	public int multiply(int a, int b, int c){
	int result = a * b * c;
	return result;
	
	}


	public static void main(String[] args) {
{

		//Create Object
	CallingMethodbyObject abc = new CallingMethodbyObject();

		//Call Method
	//abc.multiply(10, 20, 30)
	
	
	
		int x = abc.multiply(10, 25, 35);
		System.out.println(x);
	    
		//System.out.println(abc.multiply(10, 25, 35));
/*	
	int x = multiply(10, 20, 30);
	System.out.println(x);*/
	    
	//System.out.println(multiply(10, 25, 35));


	}

}
}

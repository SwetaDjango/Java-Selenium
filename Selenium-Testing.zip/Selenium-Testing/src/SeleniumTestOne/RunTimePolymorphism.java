package SeleniumTestOne;

public class RunTimePolymorphism {
	public void myMethod(){
		System.out.println("Selenium for Test Automation");
		}

	public static void main(String[] args) {

		RunTimePolymorphism obj = new RunTimePolymorphism();
		obj.myMethod();
		
	
		//RunTimePolymorphism1 obj2= new RunTimePolymorphism1();
		//obj2.myMethod();

	}

}

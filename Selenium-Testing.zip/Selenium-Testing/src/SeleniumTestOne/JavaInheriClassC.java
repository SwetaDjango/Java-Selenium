package SeleniumTestOne;

public class JavaInheriClassC extends JavaInheriClassB {
	
/*	int a =1;
	int b=2;
	public void add(){
	System.out.println(a+b);
	}
*/

	public static void main(String[] args) {
		JavaInheriClassC objC = new JavaInheriClassC();
		System.out.println(objC.a);
		objC.add();



	}

}

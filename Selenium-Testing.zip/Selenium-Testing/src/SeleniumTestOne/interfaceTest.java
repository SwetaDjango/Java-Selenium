package SeleniumTestOne;

public interface interfaceTest {

}

package SeleniumTestOne;

public interface SampleInterface {
	
	public void engine();
	public void wheels();
	public void seat();
	public void handle();
	
	public static void main(String[] args) {
		InterfaceImplementation obj= new InterfaceImplementation();
		obj.engine();
		obj.handle();
		obj.wheels();
		obj.seat();
		


	}


	

}

package SeleniumTestOne;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class ImplicitWait {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");
		//To create a new instance of Firefox Driver
				//WebDriver driver = new FirefoxDriver();
/*		System.setProperty("webdriver.gecko.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\geckodriver.exe");
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
	
		
				//Implicit Wait - Here the specified Implicit Wait time frame is 15 seconds.
				//It waits 15 seconds of time frame for the element to load. 
				//It throws an exception, if the element is not loaded within the specified time frame
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				//To open a website "Software Testing Material"
				driver.get("http://www.SoftwareTestingMaterial.com");
				//To maximize the browser window
				driver.manage().window().maximize();
				
				driver.findElement(By.linkText("EBOOK")).click();
				//To close the browser
				//driver.close();
				 The implicit wait will tell to the web driver to wait for certain amount of time before 
				 it throws a "No Such Element Exception". 
				 The default setting is 0. Once we set the time, web driver will wait for that time before throwing an exception.

In the below example we have declared an implicit wait with the time frame of 10 seconds. 
It means that if the element is not located on the web page within that time frame, it will throw an exception.
*/				
	System.setProperty("webdriver.gecko.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\geckodriver.exe");
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\chromedriver_win32\\chromedriver.exe");
		/*	WebDriver driver= new ChromeDriver();

				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				 
				//use a URL that delays loading elements
				driver.get("http://www.example.com/");
				WebElement myDynamicElement = driver.findElement(By.id("myDynamicElement"));*/
				
				WebDriver driver = new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);	
			driver.get("https://in.yahoo.com/?p=us");
			driver.manage().window().maximize();
			
			driver.findElement(By.id("uh-mail-link12")).click();
		//driver.findElement(By.id("identifierId")).sendKeys("India");

			}

	}



package SeleniumTestOne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class userDefinedTestcase1 {
	
	public static WebDriver driver;
	//Launch Browser
	public void launchBrowser(){
    driver= new ChromeDriver();   //launch chrome browser;
	}
	//Admin Login without Parameters
	public void adminLogin(){
	driver.get("http://www.gcrit.com/build3/admin/");
	driver.findElement(By.name("username")).sendKeys("admin");
	driver.findElement(By.name("password")).sendKeys("admin@123");
	driver.findElement(By.id("tdb1")).click();
	}
	//Admin Login With Parameters
	public void adminLogin(String username, String password){
	driver.get("http://www.gcrit.com/build3/admin/");
	driver.findElement(By.name("username")).sendKeys(username);
	driver.findElement(By.name("password")).sendKeys(password);
	driver.findElement(By.id("tdb1")).click();
	}
	//Close Browser
	public void closeBrowser(){
	if (! driver.toString().contains("null")){
	driver.close();
	}
	}

/*	public static void main(String[] args) {
//Test Case 1: Redirect to user Interface from Admin Interface
		System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");
		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\chromedriver_win32\\chromedriver.exe");
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\chromedriver_win32\\chromedriver.exe");

		userDefinedTestcase1 obj= new userDefinedTestcase1();
		obj.launchBrowser();
		obj.adminLogin("admin","admin@123");
		driver.findElement(By.linkText("Online Catalog")).click();
		String url = driver.getCurrentUrl();
		if (url.contains("http://www.gcrit.com/build3/")) {
			System.out.println("Redirecting to USer Interface from Admin interface. Test case passed.");
		}
		else {
			System.out.println("Not Redirecting to USer Interface from Admin interface. Test case failed.");
		}
		

	//obj.closeBrowser();
		
	}*/

	
	//Test Case 3: Admin Login Functionality with invalid inputs (Negative Testing)

	public static void main(String[] args) {
		//Test Case 1: Redirect to user Interface from Admin Interface
				System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");
				System.setProperty("webdriver.chrome.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\chromedriver_win32\\chromedriver.exe");

				userDefinedTestcase1 obj1= new userDefinedTestcase1();
				
				obj1.launchBrowser();
				//obj1.adminLogin("cfg","admin@123");
				obj1.adminLogin();
/*				String ErrorMessage = driver.findElement(By.className("messageStackError")).getText();

				if (ErrorMessage.contains("Error: Invalid administrator login attempt.")) {
					System.out.println("Handling Invalid Inputs - Passed");
				}
				else {
					System.out.println("Not Handling Invalid Inputs - Failed");
				}*/
				

			obj1.closeBrowser();
				
			}
	
}

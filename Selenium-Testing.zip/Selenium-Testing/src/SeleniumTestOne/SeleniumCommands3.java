package SeleniumTestOne;

//Refresh,quit and Close functions

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SeleniumCommands3 {

	public static void main(String[] args) throws InterruptedException  {
		
System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");

//navigate().refresh() Refresh the current web page

WebDriver driver = new FirefoxDriver();
driver.get("https://www.google.co.in");
String URL = driver.getCurrentUrl();
System.out.println(URL);
driver.navigate().refresh();
String windowid=driver.getWindowHandle();
System.out.println(windowid);
driver.manage().window().maximize();
URL = driver.getCurrentUrl();
System.out.println(URL);

Thread.sleep(5000);
//close() It closes the focused Browser.
driver.quit();

//quit() It closes all browser that opened by WebDriver during execution.

//WebDriver driver = new FirefoxDriver();
/*driver.navigate().to("https://in.yahoo.com/");//("https://login.yahoo.com/?.src=ym&.intl=us&.lang=en-US&.done=https%3a//mail.yahoo.com");
driver.findElement(By.linkText("Lifestyle")).click();

Thread.sleep(5000);

//driver.close();
driver.quit();*/

//findElement() -It finds the first element within the current page using the give locator.
//sendkeys() Enters a value into Edit box/Text box

/*WebDriver driver = new FirefoxDriver();
driver.get("http://www.gcrit.com/build3/admin/login.php");
driver.findElement(By.tagName("input")).sendKeys("asdfg");

//clear() It clears the value 
Thread.sleep(5000);
driver.findElement(By.tagName("input")).clear();


//click() Clicks an Element (Buttons, Links)

driver.findElement(By.tagName("input")).sendKeys("admin");

driver.findElement(By.name("password")).sendKeys("admin@123");
driver.findElement(By.id("tdb1")).click();*/

//isEnabled() It checks weather the Element is in enabled state or not?

/*driver.get("http://www.gcrit.com/build3/admin/login.php");
driver.findElement(By.name("username")).sendKeys("admin");
driver.findElement(By.name("password")).sendKeys("admin@123");
driver.findElement(By.id("tdb1")).click();

boolean a = driver.findElement(By.id("tdb1")).isEnabled();
System.out.println(a);

//isDisplayed() Checks if the Element is displayed or not? in the current web page.

boolean b = driver.findElement(By.id("tdb1")).isDisplayed();
System.out.println(b);*/

/*WebDriver driver = new FirefoxDriver();
driver.get("http://www.calculator.net/mortgage-calculator.html");
WebElement checkbox = driver.findElement(By.id("caddoptional"));
boolean c=checkbox.isSelected(); //true
System.out.println(c);
Thread.sleep(5000);
checkbox.click();
boolean d=checkbox.isSelected(); //false
System.out.println(d);
boolean e=checkbox.isDisplayed();
boolean f=checkbox.isEnabled();
System.out.println(e);
System.out.println(f);
*/



	}

}

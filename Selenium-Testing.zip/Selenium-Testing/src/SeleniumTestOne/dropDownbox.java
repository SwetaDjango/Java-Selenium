package SeleniumTestOne;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;


public class dropDownbox {

	public static void main(String[] args) {
		//System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");
		//WebDriver driver= new FirefoxDriver();
		
		System.setProperty("webdriver.gecko.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\geckodriver.exe");
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();

		driver.get("http://www.gcrit.com/build3/create_account.php?osCsid=47gtsrhe41613u5r3eqhgdbas7");
		
		Select dropdown =new Select(driver.findElement(By.xpath(".//*[@id='bodyContent']/form/div/div[4]/table/tbody/tr[6]/td[2]/select")));
		
		//dropdown.selectByVisibleText("Angola");
		
		dropdown.selectByIndex(1);//selecting an item in a drop box by using index1
		

		//dropdown.selectByVisibleText("India");
		
		//dropdown.selectByVisibleText("India");
		
		
		
		
		List <WebElement> e= dropdown.getOptions(); //={india, angola, Afghanstan,.....,...}
		//int e= dropdown.getOptions();
		int itemsCount= e.size();
		System.out.println(itemsCount);
		
		
		
		

	}

}

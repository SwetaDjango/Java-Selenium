package SeleniumTestOne;

public class TestMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SampleCalc obj2= new SampleCalc();
		
		int x=obj2.add(4,9);
		
		System.out.println(x);
		
		obj2.display("Adolf");
	}

}

package SeleniumTestOne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class handlingFrame {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");
	WebDriver driver= new FirefoxDriver();
		driver.get("http://seleniumhq.github.io/selenium/docs/api/java/index.html");
		//switching to a frame by knowing its index
		driver.switchTo().frame(2);
		driver.findElement(By.linkText("com.thoughtworks.selenium")).click();
		
		//switching from frame to top window
		driver.switchTo().defaultContent();
		
		//switching to a frame1 by knowing its name
		driver.switchTo().frame("packageListFrame");
		driver.findElement(By.linkText("org.openqa.selenium")).click();;
		

		
/*		Navigation:

			> Launch the page 
			> Switch to 3rd frame
			> Operate an element
			> Back to Top window
			> Switch to 1st frame (index 0)
			> Operate an element*/
		
/*	WebDriver driver = new FirefoxDriver();
		driver.get("http://seleniumhq.github.io/selenium/docs/api/java/index.html");

		//Switch to 3rd frame
		driver.switchTo().frame(2);
		driver.findElement(By.linkText("com.thoughtworks.selenium")).click();
		Thread.sleep(5000);
		//Switch from 3rd frame to Top window
		driver.switchTo().defaultContent();
		Thread.sleep(5000);
		//Switch to 1st frame
		driver.switchTo().frame(0);
		driver.findElement(By.linkText("org.openqa.selenium")).click();*/



	}

}

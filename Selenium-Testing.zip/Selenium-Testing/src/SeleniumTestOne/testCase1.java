package SeleniumTestOne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class testCase1 {

	
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		driver.get("https://en.wikipedia.org/wiki/Selenium_%28software%29");
			driver.findElement(By.linkText("Create account")).click();
		String url = driver.getCurrentUrl();
        System.out.println(url);
	if (url.contains("wikipedia.org")){
		System.out.println("It is an Internal Link - Redirected to another page in the Same Application - Test case Passed");
		}
		else{
		System.out.println("It is an External Link - Redirected to another page in the Other Application -Failed");
		}
	
	Thread.sleep(6000);
		driver.navigate().to("https://en.wikipedia.org/wiki/Selenium_%28software%29");

		driver.findElement(By.partialLinkText("Firefox 55 and ")).click(); //click
		//Thread.sleep(600);
		System.out.println("URL is: "+driver.getCurrentUrl());
		if (driver.getCurrentUrl().contains("https://seleniumhq.wordpress.com/")) {
			System.out.println("It is an External Link - Redirected to another page in the Other Application -Passed");
		}
		else {
		
			System.out.println("It is an Internal Link - Redirected to another page in the same Application -failed");
		}
		
		//driver.close();
//driver.quit();
	}

}

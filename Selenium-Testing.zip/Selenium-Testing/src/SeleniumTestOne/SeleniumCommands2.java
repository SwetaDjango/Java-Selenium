package SeleniumTestOne;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SeleniumCommands2 {

	public static void main(String[] args) throws InterruptedException {
		
//System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");
		
System.setProperty("webdriver.chrome.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\chromedriver_win32\\chromedriver.exe");
System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");

WebDriver driver= new ChromeDriver();

//navigate().forward()-It moves single item forward in the Browser history.

driver.get("https://www.google.co.in");
String URL = driver.getCurrentUrl();
System.out.println(URL);

Thread.sleep(5000);

driver.navigate().to("https://login.yahoo.com/");
URL = driver.getCurrentUrl();
System.out.println(URL);

Thread.sleep(5000);

driver.navigate().back();
URL = driver.getCurrentUrl();
System.out.println(URL);

Thread.sleep(5000);

driver.navigate().forward();
URL = driver.getCurrentUrl();
System.out.println(URL);


/*driver.get("https://www.google.co.in");
String URL = driver.getCurrentUrl();
System.out.println(URL);

driver.navigate().to("https://login.yahoo.com/");
URL = driver.getCurrentUrl();
System.out.println(URL);

driver.navigate().to("https://www.google.co.in");
URL = driver.getCurrentUrl();
System.out.println(URL);

driver.navigate().to("https://login.yahoo.com/");
URL = driver.getCurrentUrl();
System.out.println(URL);
*/


	}

}

package SeleniumTestOne;


public class VariableTypes {
	
	static int a =100;//static variable

	//mysalary variable is a Local variable.
	//mysalary method for calculating the salary hike
	
	
	  public int salary()
	  { int mysalary =10000+2000+1500; 
	  mysalary=mysalary + a;
	  return mysalary; }
	 
	public static void main (String[]args){
	//Instance variable
	int b =200;
	
	//VariableTypes.salary(); //classname.methodname () or classname.variablename.
	
VariableTypes obj= new VariableTypes(); 
	

	System.out.println(obj.salary()); 
	
	System.out.println(VariableTypes.a); 
	
	
	
	//System.out.println(a);//100
	//System.out.println(b); //200    
	        
	//
	// i is a Local Variable    
		for (int i=1; i<=5; i++){
	    System.out.println(i);
	    System.out.println(a);
	    System.out.println(b);
	}
	
	}
	
}

	
	
	
	

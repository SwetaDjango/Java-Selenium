package SeleniumTestOne;

public class PrimitiveDataTypes {
	 byte b1=123;
	 
	 int bn; // declaration
	 
	 short g=7654;
	 
	 int num1= 3458888;
	 
	 long l1= 12345678;
	 
	 float f1= 12.35657657f;
	 
	 double d1= 123.45664545656765;
	 

	 
	 String str1= "Sweta Rawat";
	 
	
	 
	 public static void main(String[] args) {
		 
		 boolean b2 = true;
		 char ch1='b';
	 System.out.println(b2);
	 
	 System.out.println(ch1);
	 
	 
	 
	 }

}

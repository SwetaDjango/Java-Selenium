package SeleniumTestOne;

public class Sample1 {
	
	//Create Method
	public static  int multiply(int a, int b, int c){
	int result = a * b * c;
	return result;
	}

	//Multiply method is internal method to Sample 1 class
	
	public static void main (String [] args){
		
/*		Sample1 obj1= new Sample1();
		int x= obj1.multiply(10, 20, 30);
		System.out.println(x);*/
		
		int x=Sample1.multiply(20, 3, 5);
		System.out.println(x);
	}


}

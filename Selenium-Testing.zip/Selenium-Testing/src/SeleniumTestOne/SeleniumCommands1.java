//Operations on a web Browser

package SeleniumTestOne;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;

public class SeleniumCommands1 {

	public static void main(String[] args) {
		
//System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");
System.setProperty("webdriver.chrome.driver","D:\\Sweta\\Web_Drivers\\chromedriver.exe");
WebDriver driver= new ChromeDriver(); //opens a blank URL

//driver.get("https://www.google.co.in"); //opens the given URl

//Current URL


//Returns Title of the Browser.
                                                                                            
driver.get("https://www.google.co.in");

/*String URL = driver.getCurrentUrl();
System.out.println(URL); //current url
String Title = driver.getTitle();
System.out.println(Title);*/

//getPageSource()-Returns HTML page source.
//driver.get("https://www.google.co.in");
//String pageSource = driver.getPageSource();
//System.out.println(pageSource);

//Browser Navigation Methods

//navigate().to()-Loads a 
//new web page in the current browser window.

driver.navigate().to("https://login.yahoo.com/");
String URL1 = driver.getCurrentUrl();
System.out.println(URL1);

//navigate().back()-It moves a single item back in the Browser history.
driver.navigate().back();//google
String URL2 = driver.getCurrentUrl();
System.out.println(URL2);

//driver.navigate().forward();//yahoo

driver.navigate().to("https://login.yahoo.com/");


}

}

package SeleniumTestOne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class elementLocators {

public static void main(String[] args)  {
	
System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");
		

//WebDriver driver= new FirefoxDriver(); //OPen firefox browser

WebDriver driver= new FirefoxDriver();

//driver.get(arg0);

//launch the browser
		//WebDriver driver= new FirefoxDriver();//OPen firefox browser



		driver.get("http://www.calculator.net/bmi-calculator.html");
		

//driver.get("https://www.google.co.in/");

//driver.findElement(By.linkText("Gmail")).click();

//driver.findElement(By.partialLinkText("Gm")).click();
/*		
		driver.findElement(By.className("innormal")).clear(); //clear existing NME
		
		driver.findElement(By.className("innormal")).sendKeys("32");
		*/
		//Thread.sleep(3000);
		
		//finding element by id.
		
		//driver.findElement(By.id("nxbdfjj")).click();
		
		driver.findElement(By.id("cage")).clear();
		

		
		
		driver.findElement(By.id("cage")).sendKeys("77");
		
		//finding element by name.
		driver.findElement(By.name("cpound")).clear();
		//driver.findElement(By.name("cpound")).sendKeys("130");
		
		//by class name
		driver.findElement(By.className("in2char")).clear();
		driver.findElement(By.className("in2char")).sendKeys("6");
		
		//driver.findElement(By.linkText("Print")).click();
		
		//driver.findElement(By.partialLinkText("Fitness and")).click();
		
		//driver.findElement(By.xpath(".//*[@id='content']/div[3]/div[2]/table[4]/tbody/tr/td[1]/input[2]")).click();
		
		driver.findElement(By.cssSelector("#cpound")).sendKeys("100");
		
		//BY link text - no need of plugin .its visible element 
		//driver.get("https://www.google.co.in/?gws_rd=ssl");
		//driver.findElement(By.linkText("Gmail")).click();;
		
		/*WebElement Email=driver.findElement(By.linkText("Gmail"));;
		Email.click();*/ 
		//to perform multiple operations
		
		//By partial link text
		//driver.findElement(By.partialLinkText("Gma")).click();;
		
		//By Css selector


	
	//driver.get("http://demoqa.com/registration/"); // open this url.
	
	//driver.findElement(By.id("name_3_firstname")).sendKeys("Sweta R");
	
	//driver.findElement(By.id("name_3_firstname")).sendKeys("Sweta");
	
	//driver.findElement(By.name("last_name")).sendKeys("Kumari");
	
	//driver.findElement(By.xpath(".//*[@id='pie_register']/li[2]/div/div/input[2]")).click();
	
	//driver.findElement(By.cssSelector("#username")").sendKeys("admin123");
	
	/*driver.findElement(By.id("name_3_firstname")).sendKeys("Sonia");
	
		driver.findElement(By.name("last_name")).sendKeys("Gupta");
		
		driver.findElement(By.xpath(".//*[@id='pie_register']/li[2]/div/div/input[2]")).click();
		
		*/
		//driver.findElement(By.cssSelector("#name_3_lastname")).sendKeys("Patil");
		
		//driver.findElement(By.cssSelector(".gb_P")).click();;
	
	//driver.findElement(By.cssSelector("#phone_9")).sendKeys("7894561232");
	
	
	//driver.findElement(By.xpath(".//*[@id='email_1']")).sendKeys("abc@gmaiol.com");
		
		//By Xpath
		/*driver.findElement(By.xpath(".//*[@id='name_3_lastname']")).sendKeys("Gupta");;;*/
		
		}

}

/**
 * 
 */
package SeleniumTestOne;

/**
 * @author Sweta
 *
 */
public interface cvb {
	
	int a =10;
	

}

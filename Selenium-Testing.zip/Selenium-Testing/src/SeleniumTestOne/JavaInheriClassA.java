
//LOGIN functionality testing
package SeleniumTestOne;

public class JavaInheriClassA {
	
	int a =10;
	int b =20;
	public void add(){
	System.out.println(a+b);
	}


	public static void main(String[] args) {
		JavaInheriClassA objA = new JavaInheriClassA();
		
		
		System.out.println(objA.a);//10
		objA.add();//30


	}

}

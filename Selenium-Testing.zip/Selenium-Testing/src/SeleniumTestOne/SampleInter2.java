package SeleniumTestOne;

public class SampleInter2 implements SampleInterface {
	
	public void engine()
	
	{System.out.println("Bikes have Engine");}
			
			
	public void wheels()
	{System.out.println("Bikes have Wheels");}
	
	
	public void seat()
	{System.out.println("Bikes have seats");}
	
	public void handle()
	
	{System.out.println("Bikes have handle");}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SampleInter2 obj= new SampleInter2();
		obj.wheels();
		obj.handle();
		

	}

}

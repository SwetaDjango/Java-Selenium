package SeleniumTestOne;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class crossBrowsertest2 {
	public static WebDriver driver;
	public static int browser;
	public static String BrowserName;


	public static void main(String[] args) throws InterruptedException {
		//System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");
		
		System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");
		


	for (browser = 1; browser <= 3; browser++){
			if (browser == 1) {
			driver = new FirefoxDriver();
			BrowserName = "Mozilla Firefox Browser: ";
			}
			else if (browser == 2) {
			//System.setProperty("webdriver.chrome.driver", "C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\chromedriver_win32\\chromedriver.exe");
			System.setProperty("webdriver.chrome.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\chromedriver_win32\\chromedriver.exe");
			driver = new ChromeDriver();//blank chrome window
			BrowserName = "Google Chrome Browser: ";
			}
			else if (browser == 3){
			System.setProperty("webdriver.ie.driver", "C:\\\\Users\\\\Sweta\\\\Desktop\\\\Manual Testing\\\\Selenium\\\\IEDriverServer_x64_3.4.0\\\\IEDriverServer.exe");
			Thread.sleep(5000);
			driver = new InternetExplorerDriver();
			BrowserName = "Internet Explorer Browser: ";
			}
			driver.get("https://www.google.com");

			String PageTitle = driver.getTitle();

			if (PageTitle.equals("Google")){
			System.out.println(BrowserName + " - Google Application Launched - Passed");
			}
			else {
			System.out.println(BrowserName + " - Google Application Not Launched -Failed");    
			}
			//driver.close();
			}
			}
			}


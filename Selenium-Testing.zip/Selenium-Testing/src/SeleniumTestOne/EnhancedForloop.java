package SeleniumTestOne;

public class EnhancedForloop {

	public static void main(String[] args) {
		
		//Using for loop
		
		//char[] vowels = {'a', 'e', 'i', 'o', 'u'};// 0 vowels[0]='a'
		
		//vowels.length ==Return an int vale (size of array)=5 :1<5

	     /* for (int i = 0; i < vowels.length; ++ i) {
	         System.out.println(vowels[i]);             //vowels[0]=a, e... Vowels[4]=u
	      }*/

	      //Using Enhanced For Loop
	      
			/*
			 * char[] vowels = {'a', 'e', 'i', 'o', 'u'};
			 * 
			 * for (char z: vowels) { System.out.println(z); }
			 * 
			 */
		
			
			  int [] mathOperations = new int[3];//size of aray=3 
			  int a=10, b=20;
			  
			  mathOperations[0]= a+b;//30 
			  mathOperations[1]= a-b;//-10
			  mathOperations[2]=a*b;//200
			  
			  for (int x: mathOperations) { 
				  System.out.println(x); 
				  }
			 

	      
	}

}

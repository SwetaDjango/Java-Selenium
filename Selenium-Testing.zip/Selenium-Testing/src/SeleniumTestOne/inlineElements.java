package SeleniumTestOne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;

public class inlineElements {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.gecko.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\geckodriver.exe");
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Sweta\\Desktop\\Manual Testing\\Download\\New folder\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		Thread.sleep(5000);
		WebElement inline=driver.findElement(By.xpath(".//*[@id='gbwa']/div[1]/a")); 
		inline.click();
		//driver.findElement(By.xpath(".//*[@id='gb36']/span[1]")).click();
		
		//driver.findElement(By.className("gb_3")).click();
		
		driver.findElement(By.id("gb36")).click();
		
		//driver.findElement(By.xpath(".//*[@id='gb1']/span[1]")).click();
		//driver.navigate().back();
		

	}

}

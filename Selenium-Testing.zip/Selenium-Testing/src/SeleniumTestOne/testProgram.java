package SeleniumTestOne;

public class testProgram {
	
  public int multiply(int a, int b, int c){
		int result = a * b * c;
		return result;
		}


	public static void main(String[] args) {

		int a = 10, b, c; //Variables Declaration    
		b = 20; c = 30; //Initialization 

		final int money =100;//Constant Declaration

		System.out.println("Addition of a, b is " + (a + b));//Addition of a, b is 30
		System.out.println(money);//100
		System.out.println(c);//30

		//Condition Block
		if (a > b){
		System.out.println("A is a Big Number");
		}
		else
		{
		System.out.println("B is a Big Nuber");
		}

		//Loop block

		for (int d=1; d <=10; d++){
		    System.out.println(d);
		}

		testProgram obj= new testProgram();
		obj.multiply(10, 10, 10);
		int x=obj.multiply(10, 10, 10);
		System.out.println(x);

	}

}

package SeleniumTestOne;

public class JavaInheritance1 {



//Example for accessing Static and Non-static Class members
		
		//Declare Static variables
		static int a =10, b=20;
		//Declare Non-static variables
		int c=30, d=40;
		//Create Static a method with returning a value
		public static int add(){
		int result = a+b;
		return result;    
		}
		//Create Static a method without returning any value
		public static void multiply(){
		System.out.println(a*b);
		}
		//Create a Non static method with returning a value
		public int add2(){
		int res = c + d;
		return res;
		}
		//Create a Non static method without returning any value 
		public void multiply2(){
		System.out.println(c*d);    
		}
		public static void main (String [] args){
		//Access Static Class Members(Using Class Name)
		int x = JavaInheritance1.add();
		System.out.println(x);//30
		System.out.println(JavaInheritance1.a);//10
		System.out.println(JavaInheritance1.b);
		JavaInheritance1.multiply();//200

		//Access Non static class members(Using Object) 
		JavaInheritance1 obj = new JavaInheritance1();
		int y = obj.add2();
		System.out.println(y);//70
		System.out.println(obj.c);//30
		obj.multiply2();//1200
		
		


	}

}

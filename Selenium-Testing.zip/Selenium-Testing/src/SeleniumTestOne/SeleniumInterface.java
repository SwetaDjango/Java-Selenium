package SeleniumTestOne;

public interface SeleniumInterface {

}

package SeleniumTestOne;

public abstract  class Bike {

		public void handle(){
		System.out.println("Bikes have Handle");
		}

		public void seat(){
		System.out.println("Bikes have Seats");
		}

		public abstract void engine();

		public abstract void wheels();


public static void main(String[] args) {
		HeroHonda obj = new HeroHonda();
		obj.engine();
		obj.wheels();
		obj.handle();
		obj.seat();


}

	
	
}



package SeleniumTestOne;

import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class crossBrowsertest1 {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");
		System.setProperty("webdriver.ie.driver", "C:\\Users\\Sweta\\Desktop\\Manual Testing\\Selenium\\IEDriverServer_x64_3.4.0\\IEDriverServer.exe");
		WebDriver driver= new InternetExplorerDriver();
		Thread.sleep(5000);
		driver.get("https://www.google.com");
		String PageTitle = driver.getTitle();
		System.out.println("Title is: "+PageTitle);
		if (PageTitle.equals("Google")){
			System.out.println("Google Application Launched - Passed");
			}
			else {
			System.out.println("Google Application Not Launched -Failed");    
			}
			driver.close();


	}

}

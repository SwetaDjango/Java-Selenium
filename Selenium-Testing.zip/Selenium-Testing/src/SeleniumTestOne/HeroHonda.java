package SeleniumTestOne;

public class HeroHonda extends Bike {

	@Override
	public void engine() {
System.out.println("Herohonda have engines");
		
	}

	@Override
	public void wheels() {
System.out.println("herohonda  have wheel");
		
	}
	
	public static void main(String[] args) {
		
		HeroHonda objHH= new HeroHonda();
		objHH.engine();
		objHH.wheels();
		objHH.seat();
		objHH.handle();
		
		
		
	}
	
	

}

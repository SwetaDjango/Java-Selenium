package SeleniumTestOne;

import org.openqa.selenium.By;
//import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class handleImage {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.gecko.driver","G:\\Saftwares BackUp\\Selenium\\geckodriver-v0.16.1-win64\\geckodriver.exe");
		WebDriver driver= new FirefoxDriver();
		
		//General Image (No functionality)
		
		driver.get("https://login.yahoo.com/");
		System.out.println(driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div/img")).isDisplayed());//true
		System.out.println(driver.findElement(By.xpath("//div[2]//div/img")).getAttribute("alt"));//Yahoo

		//Image Button (Submits)
		driver.navigate().to("http://newtours.demoaut.com/");
		driver.findElement(By.name("login")).click();
		
		Thread.sleep(5000);
		
		driver.navigate().to("http://www.seleniumhq.org/");
		driver.findElement(By.xpath("html/body/div[3]/div[2]/div[2]/table/tbody/tr/td[2]/center/a/img")).click();

	}

}

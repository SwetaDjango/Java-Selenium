package question;

public class SortString1 {
	
	public static int i;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str="100111111000010";
//print 1 first and 0s. in 111110000

System.out.println("length: "+str.length());

System.out.println(str.charAt(0));
String one="1";
String zero="0";
for(i=0;i<str.length();i++)
{
	if (str.charAt(i) == one.charAt(0))
	{
	System.out.print(str.charAt(i));
	}}

	for(i=0;i<str.length();i++){
      if (str.charAt(i) == zero.charAt(0))
		
	{
		System.out.print(str.charAt(i));
	}
	}}
}


	



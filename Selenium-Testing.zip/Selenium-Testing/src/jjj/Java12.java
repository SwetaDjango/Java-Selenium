package jjj;

import SeleniumTestOne.JavaInheriClassX;



public class Java12 extends JavaInheriClassX{

	public static void main(String[] args) {
		
		Java12 obj= new Java12();
		obj.add();


	}

}

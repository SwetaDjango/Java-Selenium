//Create a class called "Main" with two attributes: x and y:
package oops;

public class Sampleclass {
	
	  int x = 5;
	  int y = 3;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		 * Sampleclass obj = new Sampleclass(); System.out.println(obj.x);
		 * 
		 * obj.x=40; System.out.println(obj.x);
		 */
		
		Sampleclass myObj1 = new Sampleclass();  // Object 1
		Sampleclass myObj2 = new Sampleclass();  // Object 2
	    myObj2.x = 25;
	    System.out.println(myObj1.x);  // Outputs 5
	    System.out.println(myObj2.x);  // Outputs 25

	}

}

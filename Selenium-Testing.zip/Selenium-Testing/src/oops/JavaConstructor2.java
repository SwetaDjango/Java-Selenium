package oops;

public class JavaConstructor2 {
	
	
	  int modelYear;
	  String modelName;

	  public JavaConstructor2(int year, String name) {
	    modelYear = year;
	    modelName = name;
	  }

	  public static void main(String[] args) {
		  JavaConstructor2 myCar = new JavaConstructor2(1969, "Mustang");
	    System.out.println(myCar.modelYear + " " + myCar.modelName);
	  }

}

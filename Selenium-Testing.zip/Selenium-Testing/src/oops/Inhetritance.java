package oops;

public class Inhetritance {

}

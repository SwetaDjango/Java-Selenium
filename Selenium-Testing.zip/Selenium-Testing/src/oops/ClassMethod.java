package oops;

public class ClassMethod {
	
	  static void myMethod() {
		    System.out.println("Hello World!");
		  }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
myMethod();
	}

}

package oops;

public class Encapsulation2 {
	public static void main(String[] args) {
		/*
		 * Encapsulation myObj = new Encapsulation(); myObj.name = "John"; // error
		 * System.out.println(myObj.name); // error
		 */ 
		
		Encapsulation myObj = new Encapsulation();
	    myObj.setName("John"); // Set the value of the name variable to "John"
	    System.out.println(myObj.getName());
	    
	}
}

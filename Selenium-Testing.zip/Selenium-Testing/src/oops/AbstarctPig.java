package oops;

public class AbstarctPig extends AbstractionAnimal {
	public void animalSound() {
    // The body of animalSound() is provided here
    System.out.println("The pig says: wee wee");
  }
	
}

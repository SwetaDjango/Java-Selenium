package oops;

public class MainAbstract {
	 public static void main(String[] args) {
	AbstarctPig pig= new AbstarctPig();
	pig.animalSound();
	pig.sleep();

}
	 
}
